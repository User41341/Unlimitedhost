1. Upload 'SkyportPanel' folder na server
2. Podesi MySQL u config.php
3. Importuj SQL fajl