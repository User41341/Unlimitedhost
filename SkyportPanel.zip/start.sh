#!/bin/bash
echo 'Starting SAMP server...'